export class tournamentDataModel
{
  name:string=""
  startDate:string=""
  endDate:string=""
}