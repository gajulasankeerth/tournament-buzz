import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-tournament',
  templateUrl: './manage-tournament.component.html',
  styleUrls: ['./manage-tournament.component.css']
})
export class ManageTournamentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
