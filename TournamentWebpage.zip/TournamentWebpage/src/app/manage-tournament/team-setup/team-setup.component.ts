import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-team-setup',
  templateUrl: './team-setup.component.html',
  styleUrls: ['./team-setup.component.css']
})
export class TeamSetupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
